package com.joaoneto.mobilechallenge.model

import java.io.Serializable

class CurrencyModel: Serializable {
    var name: String? = null
    var valuePerDollar: Double? = null
}